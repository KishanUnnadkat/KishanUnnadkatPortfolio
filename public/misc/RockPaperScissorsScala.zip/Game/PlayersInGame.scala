/*	This is the PlayersInGame class, which sets the details for each turn every player has. Every time a new turn is taking place this class will be called initialising an
 * 	ID, choice variable and also a result MVar. The ID and choice variables are stored as variables to keep a track of each players choice and ID. The result is of type
 * 	MVar as there can only be one result in the MVar at one time. Once it is taken by the Player thread, it will become empty for the referee to set later on. The MVar
 * 	stores an Int variable hence the [Int] after the MVar. This class initialises the variables and declares public methods allowing the methods to be called in different classes.
 */

class PlayersInGame {
  
    var PlayerID = 0                               // Sets up the ID variable initially set to 0, but will change when the PlayerThread is run as it will call setID method within this class to correct ID.
    var choice = Shape.choicesFunction()           // Sets up a variable called choice which is by default set to the choicesFunction (Random shape generator) - Will change when PlayerThread is run by calling setChoice method.
    var result: MVar[Int] = new MVar[Int]()        // Sets up an MVar called result storing the result of the player, which will change once the referee has set the MVar. The result will then be taken by the PlayerThread,
                                                   // to store number of wins, losses and draws.
    
    def getID(): Int = {                           // A method called getID, which simply returns the ID back to the class where it is being called.
      return PlayerID                              // This method is of type Int as the ID returned will always be of type Int (eg. ID will be 1,2,3,4 etc)
    }
    def setID(passedID: Int) {                     // This is a method within this class to set the ID variable to the correct PlayerID. This method takes in
      this.PlayerID = passedID                     // an int from the PlayerThread and sets the ID within this class to whatever the variable was being passed in.
    }
    
    def getChoice(): String = {                    // A method called getChoice, which returns a String back to the class where it is being called.
      return choice                                // This method gets the choice variable from the Shape.choicesFunction. Returns either ROCK, PAPER OR SCISSORS.
    }
    def setChoice(passedChoice: String) {          // This is a method called setChoice, which does exactly what it says and sets the choice variable within this class
      this.choice = passedChoice                   // to the variable passed in from the PlayerThread when a choice is set. The PlayerThread calls the setChoice
    }                                              // and stores the contents passed in inside a variable called choice. The variable at the top of this class is then set.
    
    def getMVar(): MVar[Int] = {                   // A method called getMVar, which returns the details of the MVar back including isSet and the state of the MVar.
      return result                                // The state stores the Int variable of the result either -1, 0 or 1 and can be retrieved using TakeMVar function.
    }
    def SetMVar(passedNumber: Int) {               // This method called SetMVar is called by the RefereeThread within the Referee class to keep a track of the result of each
      result.putMVar(passedNumber)                 // player when they have taken one turn. (eg. If p1 plays p2 and both draw - Referee will call this method and set the MVar)
    }                                              // so it can be called later within the PlayerThread.
}