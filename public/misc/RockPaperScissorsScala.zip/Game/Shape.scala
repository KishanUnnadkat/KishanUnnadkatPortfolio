/*	This is the shape class which defines an object called shape consisting of two functions - choicesFunction which chooses a shape randomly and
 * 	returns it back to the player thread, and the winningPlayerFunction, which calculates the result to be used by the referee thread. This result
 * 	will give a corresponding output such as "Player 1/2 wins/loses/draws" depending on the shapes chosen. This class is called by both the Player
 * 	and Referee thread to calculate the Shape chosen by the player and the result for the referee to output the result of each turn.
 */
import scala.util.Random

object Shape {
  /* 	This is the first function within the Shape class called choicesFunction - This function sets up an array of choices (ROCK, PAPER, SCISSORS)
   * 	for the choice to be randomly picked. This array is a val as it won't change throughout as it has fixed values. Another val is declared called picked,
   * 	which shuffles the array values by random and picks the first element (head) within the shuffled array. It will then return the picked variable back
   * 	to the Player thread (Random as we don't know what the head of the shuffled array will be).
   */
	def choicesFunction(): String = {
			val choices = Array("ROCK", "PAPER", "SCISSORS")        // Sets up the array of shapes - ROCK, PAPER, SCISSORS
		  val picked = Random.shuffle(choices.toList).head        // Chooses a random shape by shuffling the array and choosing the first element
			return picked                                           // Returns the chosen shape back to the player thread.
	}

	
	/*	This is the second function within the Shape class called WinningPlayerFunction which does exactly what the name is and it returns a result
	 * 	either -1, 0 or 1 to the referee thread. There are two parameters being passed into this function, which is both of the Players choices (set
	 * 	by the function above). If the First player wins the result 1 is given back to the referee, if the First player loses the result
	 * 	of 0 is given back to the user else if both players choose the same shape, the result -1 is given out. I have implemented a case statement as it 
	 * 	makes it a lot more maintainable if something goes wrong and is very easy to follow. If the case statements fail, a new exception will be thrown
	 *  	giving a friendly error message back to the user else the result is then fed back into the referee thread to give corresponding outputs.
	 */
	def WinningPlayerFunction(PlayerOne:String, PlayerTwo:String): Int = {  // New function called WinningPlayerFunction which takes in 
	  PlayerOne match {                                                     // two parameters of both players choices and calculates a result                                           
	    case "PAPER" =>                                                     // depending on if the result of the game is a win, draw or loss.
			PlayerTwo match {                                                   // This is called by the referee thread to calculate the result of each player.
			  case "PAPER"    => -1
			  case "SCISSORS" => 0
			  case default    => 1
			}
			
	    case "ROCK"  => 
	    PlayerTwo match {
	      case "ROCK"     => -1
	      case "PAPER"    => 0
	      case default    => 1
			}
			
			case "SCISSORS" => 
			PlayerTwo match {
			  case "SCISSORS" => -1
			  case "ROCK"     => 0
			  case default    => 1
			}
			
			case default  =>  throw new IllegalArgumentException("Oops... A result could not be determined") //If all fails and no result can be set, by default it will throw a new exception of type IllegalArgumentException
		}	                                                                                                     // with a friendly notification to the user about the error.
	}
}