/*	This is the Referee class which consists of a thread called RefereeThread. Initially it creates a Queue called PlayerQueue holding variables of type PlayersInGame
 * 	within (Therefore each having an ID, choice and result). This will be the queue where players are added to, and the Referee randomly selects two
 * 	players wanting to play a game of Rock, Paper, Scissors by using the dequeue function. The RefereeThread within this class is a thread to select two players to play
 *  at once, calculate the results of the players and outputs the corresponding result to the user on the terminal saying which Player wins or if they draw etc.
 *  Once the PlayerQueue has one or less players ready to play Rock, Paper, Scissors it will then terminate and output a message to say it is terminating and 
 *  change the InGame variable to false stopping the while loop running.
 */

import scala.collection.mutable.Queue

object Referee extends Thread {
	var PlayerQueue = Queue[PlayersInGame]()                      // Creates a new Queue called PlayerQueue holding variables of type PlayersInQueue (holding an ID, choice and result) - Players turns will
	                                                              // then be enqueued (added) to the queue from the PlayerThread and be dequeued (removed) when two players turns have been selected.
			
	def RefereeThread() : Unit = {                                // Creates a new function called RefereeThread which will carry out all the functionality the thread should.
	        var InGame = true                                     // Initialises a variable of type boolean to true initially so all Players can be added to the queue. This variable will change to false when there is one or less players waiting to play.
				  var GameResult = 0                                    // Initialises a variable called GameResult holding a value of 0 initially but will change once the WinningPlayerFunction has been run to calculate a result.
				  var PlayerOne: PlayersInGame = new PlayersInGame()    // Initialises a new variable  called PlayerOne of type PlayersInGame holding its default values (ID=0, Random Shape and Result MVar) - Will change once Players turns have been dequeued from PlayerQueue.
					var PlayerTwo: PlayersInGame = new PlayersInGame()    // Initialises a new variable  called PlayerTwo of type PlayersInGame holding its default values (ID=0, Random Shape and Result MVar) - Will change once Players turns have been dequeued from PlayerQueue.
					                                                      // There are only two variables of type PlayersInGame as only two players can play Rock, Paper Scissors at any one time.                                           
					                                                      
				  while (InGame) {                                      // While InGame variable is true then carry out this functionality stated, however when there are insufficient turns within the queue it will stop running by setting InGame to false.
				    if (PlayerQueue.length >= 2) {                      // Once there are more than 2 turns within the PlayerQueue it will dequeue two turns from there and store their
						  PlayerOne = PlayerQueue.dequeue()                 // details within the PlayerOne and PlayerTwo variables we initialised of type PlayersInGame each holding an ID, Choice and Result MVar.
							PlayerTwo = PlayerQueue.dequeue()
						}
						GameResult = Shape.WinningPlayerFunction(PlayerOne.getChoice(), PlayerTwo.getChoice())  // Calculates the GameResult by using WinningPlayerFunction within the Shape class to find a result.
						                                                                                        // It has the two players choices passed as parameters and returns a result of 1, 0 or -1 depending on if PlayerOne wins/loses/draws
						var Message = ""                                                                        // Sets up a new variable called Message initially set to "" but will change depending on the result we just calculated.
						GameResult match {
						  case -1 => Message = "It's a draw"                                // Case statement to match the GameResult from the WinningPlayerFunction to the message so for example
						  case 0  => Message = "Player " + PlayerTwo.getID + " wins"        // If it was 1 or 0 it will output the correct player who won or if the players choices were the same                         
						  case 1  => Message = "Player " + PlayerOne.getID + " wins"        // It will output a draw message. If it isn't 1, 0 or -1 it will throw a new IllegalArgumentException
						  case default => throw new IllegalArgumentException("Oops... The referee could not output a result")      // with a friendly error message to notify the user there was an error.
						}
						println("Player " + PlayerOne.getID() + " (" + PlayerOne.getChoice() + ") <-> Player " + PlayerTwo.getID() + " (" + PlayerTwo.getChoice() + ") ==> " + Message)  //Outputting to the terminal both players information for that turn and the outcome of that game.

						if (GameResult == -1) {                                             // If statements to set the result MVar of the individual results of each player to keep a track of within the PlayerThread
						  PlayerOne.SetMVar(-1)                                             // If the GameResult within the Shape.WinningPlayerFunction was -1 then it would be a draw so this case statement sets both players MVar state
						  PlayerTwo.SetMVar(-1)                                             // to -1 to show that they drawed. This will be used when the PlayerThread gets the MVar and takes the result from the MVar to keep
						}                                                                   // a track of the number of wins, losses and draws for each player.
						else if (GameResult == 0) {                                         // If the GameResult was 0 from the WinningPlayerFunction then that means the Second Player wins but the first player loses hence will
						  PlayerOne.SetMVar(0)                                              // Set the result MVar for the First player who loses to 0 and Second player (the winner) sets a result of 1 inside the MVar.
						  PlayerTwo.SetMVar(1)
						}
						else if (GameResult == 1) {                                         // If the result is 1 from the WinningPlayerFunction then the first person playing has won
						  PlayerOne.SetMVar(1)                                              // hence this function will call the SetMVar method in the PlayersInGame class to change the result MVar and will put the number
						  PlayerTwo.SetMVar(0)                                              // 1 inside the winning players result and 0 inside the losing players result - First Player wins, Second loses
						}
						else
						  println("Oops... There is an error in the Referee class")         // If the result isn't 1, 0 or -1 it will output a friendly error message to notify the user there was an error.
						  
						Thread.sleep(1)      // Makes this thread sleep for 1 millisecond so that the PlayerThread can jump in and update the players turns within the PlayerQueue for them to be added 
							                   // if more players wish to play. This will constantly be updated until there is either only 1 turn left to play or no turns left to play as a game needs 2 or more turns to play.
						
					  if (PlayerQueue.length <= 1) {              // If the PlayerQueue is less than one or PlayerQueue is one it will output a message back to the user to notify them that the referee 
							println("Referee thread - terminating")   // thread is terminating as two or more turns need to be within the queue to play a game and will change the state of the InGame variable
							InGame=false                              // to false so that the while loop wont run as the condition is now false and not true - There is not sufficient turns in the 
							                                          // Queue to play Rock, Paper, Scissors and will exit the program once all turns possible have been played. (Graceful shutdown)	
					  }	  
				  }
	}
}