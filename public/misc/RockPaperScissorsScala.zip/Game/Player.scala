/*	This is the Player class which extends thread as it is a thread running concurrently with the referee thread. Within this Player class, there is a PlayerThread thread
 * 	which takes in a parameter of i given from the Game class when initialised (initial value of 0 each time for the ID of the player) . This class sets up a PlayerThread
 *  for each player there is given from the Game class. This PlayerThread sets up each player and adds their turn to the queue and then waits for the refereeThread within 
 *  the referee class to choose them from the queue. Once the players are chosen from the queue by the referee, the referee calculates the result and passes it back
 * 	to this Player Thread. The result variable is set as an MVar as there can only be one result in the MVar variable at one time. Once the player has been chosen and 
 *  exhausted all their turns, it will output a message to the user to notify that the player has stopped.
 */

object Player extends Thread {
  
	def PlayerThread(i : Int): Unit = {
	  
	    var NTURNS = Game.NTURNS                        // var to set number of turns for each player (set as var as will decrease throughout) - Can be changed by the user.
			var loss, win, draw = 0                         // number of wins, losses and draws for each player initially set to 0, Increase accordingly.
			var counter = Game.PlayerID.takeMVar() + 1      // This is a variable counter, which we use to keep a track of the ID which has been passed in by value into this thread.
			Game.PlayerID.putMVar(counter)			            // This will be used for keeping an eye on what ID has currently been set.

			/*	This is the for loop which iterates through till the number of turns have been exhausted for each player. Firstly it creates a new variable
			 * 	called PlayersInGame as a turn holding the fields - ID, choice, result. Each turn for each player is calculated using this while loop and stored
			 * 	in the PlayersInGame class. This PlayerThread sets both the playerID and choice and then enqueues the players turns to the queue using synchronisation.
			 * 	As it will synchronise with the playerQueue in the referee class, it will add the PlayersInfo turn to the queue using enqueue. Once the PlayerInfo has 
			 * 	been set, the referee will then calculate the result and output the result of the player. It will then jump back into this class after the referee has
			 *  completed to take the Players result from the MVar within the PlayersInGame class. It will then calculate and keep a track of the number of wins, losses
			 *  and draws, which the user has recieved and decrease the number of turns as the player has had one of their turns. Once the number of turns hits 0, the 
			 * 	player has exhausted their number of turns and an output message will display on the terminal to say the player thread has stopped and will output 
			 *  total number of wins, losses and draws that player had over their number of turns.
			 */
			while (NTURNS!=0)                                           // While loop to iterate through till the number of turns has reached 0 for each player.
			{
				var PlayerInfo: PlayersInGame = new PlayersInGame         // Sets up variable called playerInfo which is a new PlayersInGame storing ID, choice & result for their turn
				PlayerInfo.setID(counter)                                 // Sets the PlayerID to the variable counter, which we saw earlier within this PlayerThread (counter stores the correct ID)
				PlayerInfo.setChoice(Shape.choicesFunction())             // Sets the playerInfo choice to the choices function within the Shape class - Randomly generates a shape to store using choicesFunction in Shape class.

				Referee.PlayerQueue.synchronized {                        // This is the synchronisation block, which adds the PlayerInfo turn to the PlayerQueue within the referee class.
					Referee.PlayerQueue.enqueue(PlayerInfo)                 // The referee thread then carries on, until output is given to the terminal and a result has been calculated.
				}                                                         // Once the referee thread has done the work it needs to, this thread will then carry on as normal.

				var GameResult = PlayerInfo.getMVar.takeMVar()		        // A result variable is created which gets the MVar data within the PlayerInfo variable and takes the result (Declared in PlayersInGame)
				                                                          // If at this point in time there is no value to take within the MVar, it will wait for a value to be put in then continue.
				
				if (GameResult == -1)                                     // These if statements calculate the number of wins, losses and draws depending on the result which was calculated
					draw = draw + 1                                         // by the referee thread. If the result calculated by the referee thread was 1, it will be stored as a win
				else if (GameResult == 0)                                 // else if the result calculated was 0, then it will be stored as a loss, otherwise if the result given by the 
					loss = loss + 1                                         // referee was -1, it will be stored as a draw. The number of wins, losses and draws will be increased every time
				else if (GameResult == 1)                                 // a pair of players have had one turn depending on if they won/loss/drew the game
					win = win + 1  

				NTURNS -= 1                                               // Decrease the number of turns (NTURNS) by one for that player until each player has exhausted all their turns.
				if(NTURNS==0)                                             // If the number of turns hits 0 and each player has had their turns, it will output a message to the terminal to notify when the player
					println("\t\tPlayer " + PlayerInfo.getID + " Thread stopped (" + win + " wins, " + draw + " draws, " + loss + " losses ==> Total Turns = " + Game.NTURNS + ")")  //has had all their turns with their results.
			}
	}
}