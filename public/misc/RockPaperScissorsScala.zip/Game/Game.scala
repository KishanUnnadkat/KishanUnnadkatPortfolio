/* 	This is the main scala file which sets up both the player thread and referee thread.
 * 	It intially sets up a number of players NPLAYERS which can be set by the user upon their preference.
 * 	Once all the players have been set up by the main function which is run, it will start the referee thread,
 * 	then the player thread and referee thread can run concurrently. Once the player thread has started, it will automatically
 * 	be delegated for the player thread to deal with and likewise with the referee thread. Both the threads will then
 * 	be joint at the end once they have started to give an output back to the user. All this initialisation is kept in this object
 * 	called Game. There is error trapping within the main function to ensure the number of players * number of turns doesn't equal
 *  1 hence ensures each player gets a turn in the end.
 *  
 *  NOTE to compile:
 *  Step 1 - javac MVar.java
 *  Step 2 - scalac Shape.scala PlayersInGame.scala Player.scala Referee.scala Game.scala
 *  Step 3 - scala Game
 */

import java.io.IOException;           // Importing the IOException library as this type of error may be thrown when joining threads
import java.util.concurrent._         // Importing scala concurrent library as threads will be run in parallel
import java.lang.Thread               // Importing scala thread library as creating new threads to run concurrently

@throws(classOf[IOException])  //Scalas way of saying this object - Game, may throw an IOException.
object Game {

	var PlayerID: MVar[Int] = new MVar[Int]()  //Set up an MVar called playerID of type MVar[Int] as it is an MVar holding an int inside. Used to make sure
	PlayerID.putMVar(0)                        //player IDs are unique. Putting value of 0 initially inside the MVar temporarily (Will change throughout)
	val NPLAYERS = 10     //Sets up number of players stored inside variable called NPLAYERS (User can change this). val is used as NPLAYERS wont change throughout.
	val NTURNS = 10       //Sets up number of turns stored inside a variable called NPLAYERS (Set as global so PlayerThread can access this variable)
	
	/*	Creates a new thread called called player, which is called NPLAYERS number of times, which fills up the array with NPLAYERS. If NPLAYERS was 10, this therefore
	 *  when called by main fills the array with 10 Players and sets an initial ID for each player to 0 temporarily. This will be set properly in the player thread.
	 */ 
	val player = Array.fill(NPLAYERS) {
	  new Thread {
	    override def run {
	      Player.PlayerThread(0)  //Temporarily passes an ID of 0 every time a player is initialised.
	    }
	  }
	}
	
	/*	Creates a new thread called referee which sets the RefereeThread function located within the Referee class. The referee is started from main
	 * 	to keep a track of the result of the players and maintain a queue for players waiting to play. The results are then calculated and output
	 * 	of the winning player is given all by the referee within the RefereeThread. Only one referee started at the beginning and runs concurrently
	 * 	with the player threads.
	 */
	val referee = new Thread {
		override def run {
			Thread.sleep(250)
			Referee.RefereeThread            //sets location of referee thread and starts RefereeThread when started by main.
		}
	}

	/*	This is the main function within scala where the player threads are started and the referee is started at the same time. The foreach function
	 * 	in player.foreach(_.start) gets the NPLAYERS and physically starts the player thread NPLAYERS number of times. The referee is just started once
	 * 	as there should only be one referee in total giving the output of winners and players. There is a try catch statement to join the player threads
	 * 	and referee threads together to actually provide output to the user. It will try to join the threads together but it will try and catch the exception
	 * 	if one is thrown. Error traps and makes sure the NPLAYERS*NTURNS%2==1 to make sure there isn't a left over player in the end.
	 */
	def main(args: Array[String]) {
		  
	  if (NPLAYERS*NTURNS%2==1)        //Ensuring the NPLAYERS*NTURNS%2==1 so that players aren't left out in the end.
	    println("Please do not leave out players that will not finish their turns (increase number of turns or players by 1)")
	  else {
	    player.foreach(_.start)        //starting the player thread NPLAYERS times using the foreach(_.start) function using configuration above.
		  referee.start                  //starting one single referee thread up using configuration above.
		  
		  try {                          //Try-catch statement to try and join the player threads to referee thread. If an exception is thrown, it
			  player.foreach(_.join)       //will be caught by this try-catch block.
			  referee.join()
		  } catch {
		  case ioe: IOException => ioe.printStackTrace()  //printing errors if try-catch block fails.
		  }
	  }
	}
}