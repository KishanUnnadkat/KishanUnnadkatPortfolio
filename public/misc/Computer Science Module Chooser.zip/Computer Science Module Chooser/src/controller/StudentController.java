package controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Iterator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ListView;
import model.Course;
import model.Module;
import model.StudentProfile;
import view.StudentMenuBar;
import view.StudentRootPane;
import view.CreateProfileTab.CreateProfileTab;
import view.ModulesTab.ModulesTab;
import view.OverviewSelectionTab.OverviewSelectionTab;

public class StudentController implements Iterable<Module> {

	private StudentProfile model;
	private StudentRootPane view;
	private StudentMenuBar StudentMenu;
	private CreateProfileTab cpt;
	private ModulesTab mt;
	private OverviewSelectionTab op;

	public StudentController(StudentRootPane view, StudentProfile model) {
		this.model = model;
		this.view = view;

		cpt = view.getCreateProfileTab();
		cpt.populateComboBox(setupAndGetCourses());
		mt = view.getModulesTab();
		op = view.getOverviewSelectionTab();
		StudentMenu = view.getMenuBar();
		this.attachEventHandlers();
	}

	private void attachEventHandlers() {
		StudentMenu.addLoadHandler(new LoadMenuHandler());
		StudentMenu.addSaveHandler(new SaveMenuHandler());
		StudentMenu.addExitHandler(e -> System.exit(0));
		StudentMenu.addAboutHandler(e -> this.alertDialogBuilder(AlertType.INFORMATION, "Information Dialog", null, "Student Profile Planner Version 1.0")); //lambda uses internal dialog method - see end of class

		cpt.addProfileListener(new CreateProfileHandler());
		mt.addResetListener(new ResetHandler());
		mt.addRemoveHandler(new RemoveHandler());
		mt.addAddHandler(new AddHandler());
		mt.addSubmitHandler(new SubmitHandler());
		op.addOverviewHandler(new SaveOverviewHandler());
	}

	private class LoadMenuHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			//Load StudentProfile information on Create Profile page
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("StudentProfile.dat"));) {
				model = (StudentProfile) ois.readObject();
			}
			catch (IOException ioExcep){
				System.out.println("Error loading");
			}
			catch (ClassNotFoundException c) {
				System.out.println("Class Not found");
			}
			cpt.setStudentDetails(model);

			//Loads Modules information on modules tab
			Course course = model.getCourse();
			PopulateModules(course.getModulesOnCourse());

			ListView<Module> modules = new ListView<Module>();
			ObservableList<Module> items = FXCollections.observableArrayList();
			try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("SavedModulesState.dat"));) {

				int size = ois.readInt();
				for(int i=0; i<size; i++) {
					Module module = (Module) ois.readObject();
					items.add(module);
				}
				modules.setItems(items);
				mt.setSelectedList(modules);
			}
			catch (IOException ioExcep){
				System.out.println("IOException");
			}
			catch (ClassNotFoundException c) {
				System.out.println("ClassNotFoundException");
			}

			//Loads overview page with textfield populated
			op.clearStudentProfile();
			try (BufferedReader br = new BufferedReader(new FileReader("OverviewState.txt"))) {
				String line;
				while ((line = br.readLine()) != null) {
					op.setStudentProfile(line + "\n");
				}
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			alertDialogBuilder(AlertType.INFORMATION, "Information Dialog", "Load success", "All fields which can be loaded, have been loaded");
		}
	}
	private class SaveMenuHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			//Save student Profile information page
			setStudentModel();
			try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("StudentProfile.dat"));
				oos.writeObject(model);
				oos.flush();
				oos.close();
			} catch (IOException x) {
				System.out.println("IO Exception found");
				x.printStackTrace();
			}

			//Save selected modules state
			try {
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("SavedModulesState.dat"));
				oos.writeInt(mt.getSelectedList().getItems().size());

				for(int i=0; i<mt.getSelectedList().getItems().size(); i++) {
					Module m = mt.getSelectedList().getItems().get(i);
					oos.writeObject(m);
				}
				oos.close();
				oos.flush();
			} catch (IOException x) {
				System.out.println("IO Exception found");
				x.printStackTrace();
			}

			//Save overview state
			ObservableList<CharSequence> paragraph = op.getStudentProfile().getParagraphs();
			Iterator<CharSequence>  iter = paragraph.iterator();
			try
			{
				BufferedWriter bf = new BufferedWriter(new FileWriter(new File("OverviewState.txt")));
				while(iter.hasNext())
				{
					CharSequence seq = iter.next();
					bf.append(seq);
					bf.newLine();
				}
				bf.flush();
				bf.close();
			}
			catch (IOException x) {
				x.printStackTrace();
			}
			alertDialogBuilder(AlertType.INFORMATION, "Information Dialog", "Save success", "StudentProfile saved to StudentProfile.dat");
		}
	}
	//helper method to build dialogs
	private void alertDialogBuilder(AlertType type, String title, String header, String content) {
		Alert alert = new Alert(type);
		alert.setTitle(title);
		alert.setHeaderText(header);
		alert.setContentText(content);
		alert.showAndWait();
	}


	private class CreateProfileHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			mt.ResetLists();

			if (cpt.getFirstName().equals("")||cpt.getLastName().equals("")||cpt.getPNumberInput().equals("")||cpt.getEmailInput().equals("")||cpt.getDateTxt().equals("")
					|| cpt.getPNumberInput().length()!=9 ||cpt.getPNumberInput().toUpperCase().charAt(0)!='P')
				alertDialogBuilder(AlertType.ERROR, "Error Dialog", "Incorrect fields", "Please check your details again before continuing");
			else {
				view.fadeAnimation();
				setStudentModel();
				view.changeTab(1);
				Course course = cpt.getCourseChoice();
				PopulateModules(course.getModulesOnCourse());
				view.setProgressBar(view.getProgressBar()+0.33);
				view.setProgressIndicator(view.getProgressIndicator()+0.33);
			}
		}
	}
	private class ResetHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			if (mt.getUnselectedListSize()==0) {
				mt.ResetLists();
				view.fadeAnimation();
			}
			else {
				Course course = cpt.getCourseChoice();
				PopulateModules(course.getModulesOnCourse());
				view.fadeAnimation();
			}
		}
	}
	private class AddHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			try {
				int credit = mt.getTotalCredit();
				int ChosenModuleCredits = mt.getSelectedItemInUnselectedList().getCredits();

				if((credit+ChosenModuleCredits)<=120) {
					credit += mt.getSelectedItemInUnselectedList().getCredits();
					mt.setCredits(Integer.toString(credit));
					mt.addSelectedModule(mt.getSelectedItemInUnselectedList());
				}
			}
			catch(NullPointerException x) {
				alertDialogBuilder(AlertType.ERROR, "Error Dialog", "Cannot Add", "Cannot Add as nothing is selected...");
			}
		}
	}
	private class RemoveHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			try {
				int credit = mt.getTotalCredit();
				if(mt.IsSelectedListItemMandatory()==false) {
					credit -= mt.getSelectedItemInSelectedList().getCredits();
					mt.setCredits(Integer.toString(credit));
					mt.addUnselectedModule(mt.getSelectedItemInSelectedList());
				}
			} catch (NullPointerException x) {
				alertDialogBuilder(AlertType.ERROR, "Error Dialog", "Cannot Remove", "Cannot Remove as nothing is selected...");
			}
		}
	}
	private class SubmitHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			int credit = mt.getTotalCredit();

			if(credit!=120)
				alertDialogBuilder(AlertType.INFORMATION, "Information Dialog", "Check Modules", "Please choose credits which add up to 120");
			else {
				String FullName = "Full Name: " + cpt.getFirstName() + " " + cpt.getLastName() + "\n";
				String PNumber = "P Number: " + cpt.getPNumberInput() + "\n";
				String Email = "Email: " + cpt.getEmailInput() + "\n";
				String Date = "Date: " + cpt.getDateTxt() + "\n\n";
				String Course = "Course: " + cpt.getCourseChoice().toString();
				String Module = "\nSelected Modules:\n==============\n";

				for(int i = 0; i<mt.getSelectedList().getItems().size(); i++) {
					Module m = mt.getSelectedList().getItems().get(i);

					String MandatoryYOrN = "";
					if(m.isMandatory())
						MandatoryYOrN = "Yes\n\n";
					else
						MandatoryYOrN = "No\n\n";

					Module = Module + m.toString() + ", Credits: " + m.getCredits() + "\nMandatory on your course? " + MandatoryYOrN;
					model.addSelectedModule(m);
				}
				view.setProgressBar(view.getProgressBar()+0.34);
				view.setProgressIndicator(view.getProgressIndicator()+0.34);
				view.fadeAnimation();
				view.changeTab(2);
				op.getStudentProfile().setText(FullName + PNumber + Email + Date + Course + Module);
			}
		}
	}
	private class SaveOverviewHandler implements EventHandler<ActionEvent> {
		public void handle(ActionEvent e) {
			try {
				alertDialogBuilder(AlertType.CONFIRMATION, "Confirmation Dialog", "Save Overview", "Are you sure you want to save the overview to StudentOverview.txt?");
				PrintWriter writer = new PrintWriter("StudentOverview.txt");
				writer.println("Full Name: " + model.getStudentName().getFullName());
				writer.println("P Number: " + model.getpNumber());
				writer.println("Email Address: " + model.getEmail());
				writer.println("Date:" + model.getDate());
				writer.println("\nCourse: " + model.getCourse());
				writer.println("Selected Modules:\n==============");

				for(int i = 0; i<mt.getSelectedList().getItems().size(); i++) {
					Module m = mt.getSelectedList().getItems().get(i);
					writer.println(m.toString());
				}
				writer.close();
			} catch (FileNotFoundException x) {
				x.printStackTrace();
				System.out.println("Error Saving Overview");
			}
		}
	}



	public void setStudentModel() {
		model.setCourse(cpt.getCourseChoice());
		model.setpNumber(cpt.getPNumberInput());
		model.setStudentName(cpt.getNameInput());
		model.setEmail(cpt.getEmailInput());
		model.setDate(cpt.getDateTxt());
	}
	public void PopulateModules(Collection<Module> AllModules) {
		mt.ResetLists();
		mt.setCredits(Integer.toString(0));
		int credit = mt.getTotalCredit();

		for (Module m: AllModules) {
			if (m.isMandatory()) {
				mt.addSelectedModule(m);
				credit += m.getCredits();
			}
			else mt.addUnselectedModule(m);
		}
		mt.setCredits(Integer.toString(credit));
	}
	private Course[] setupAndGetCourses() {
		Module ctec3903 = new Module("CTEC3903", "Software Development Methods", 15, true);
		Module imat3451 = new Module("IMAT3451", "Computing Project", 30, true);
		Module ctec3902_SoftEng = new Module("CTEC3902", "Rigerous Systems", 15, true);
		Module ctec3902_CompSci = new Module("CTEC3902", "Rigerous Systems", 15, false);
		Module ctec3110 = new Module("CTEC3110", "Secure Web Application Development", 15, false);
		Module ctec3426 = new Module("CTEC3426", "Telematics", 15, false);
		Module ctec3604 = new Module("CTEC3604", "Multi-service Networks", 30, false);
		Module ctec3410 = new Module("CTEC3410", "Web Application Penetration Testing", 15, false);
		Module ctec3904 = new Module("CTEC3904", "Functional Software Development", 15, false);
		Module ctec3905 = new Module("CTEC3905", "Front-End Web Development", 15, false);
		Module imat3410 = new Module("IMAT3104", "Database Management and Programming", 15, false);
		Module imat3404 = new Module("IMAT3404", "Mobile Robotics", 15, false);
		Module imat3406 = new Module("IMAT3406", "Fuzzy Logic and Knowledge Based Systems", 15, false);
		Module imat3429 = new Module("IMAT3429", "Privacy and Data Protection", 15, false);
		Module imat3902 = new Module("IMAT3902", "Computing Ethics", 15, false);
		Module imat3426_CompSci = new Module("IMAT3426", "Information Systems Strategy and Services", 30, false);

		Course compSci = new Course("Computer Science");
		compSci.addModule(ctec3903);
		compSci.addModule(imat3451);
		compSci.addModule(ctec3902_CompSci);
		compSci.addModule(ctec3110);
		compSci.addModule(ctec3426);
		compSci.addModule(ctec3604);
		compSci.addModule(ctec3410);
		compSci.addModule(ctec3904);
		compSci.addModule(ctec3905);
		compSci.addModule(imat3410);
		compSci.addModule(imat3404);
		compSci.addModule(imat3406);
		compSci.addModule(imat3429);
		compSci.addModule(imat3902);
		compSci.addModule(imat3426_CompSci);

		Course softEng = new Course("Software Engineering");
		softEng.addModule(ctec3903);
		softEng.addModule(imat3451);
		softEng.addModule(ctec3902_SoftEng);
		softEng.addModule(ctec3110);
		softEng.addModule(ctec3426);
		softEng.addModule(ctec3604);
		softEng.addModule(ctec3410);
		softEng.addModule(ctec3904);
		softEng.addModule(ctec3905);
		softEng.addModule(imat3410);
		softEng.addModule(imat3404);
		softEng.addModule(imat3406);
		softEng.addModule(imat3429);
		softEng.addModule(imat3902);

		Course[] courses = new Course[2];
		courses[0] = compSci;
		courses[1] = softEng;

		return courses;
	}
	@Override
	public Iterator<Module> iterator() {
		return model.getSelectedModules().iterator();
	}
}