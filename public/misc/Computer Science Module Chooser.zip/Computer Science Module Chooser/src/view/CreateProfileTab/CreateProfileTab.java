package view.CreateProfileTab;

import java.time.LocalDate;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import model.Course;
import model.Module;
import model.Name;
import model.StudentProfile;
import javafx.util.Callback;

public class CreateProfileTab extends GridPane {

	private ComboBox<Course> ModuleChoice;
	private TextField PNumberTxt, FirstNameTxt, LastNameTxt, EmailTxt;
	private DatePicker DateTxt;
	private Button CreateProfileBtn;
	private ListView<Module> listModel;

	public CreateProfileTab() {
		this.setPadding(new Insets(60,80,80,80));
		this.setVgap(15);
		this.setHgap(10);
		this.setAlignment(Pos.CENTER);

		Label lblModuleChoice = new Label("Select Course: ");
		Label lblPNumber = new Label("Input P Number: (Include P)");
		Label lblFirstName = new Label("Input First Name: ");
		Label lblLastName = new Label("Input Last Name: ");
		Label lblEmail = new Label("Input Email: ");
		Label lblDate = new Label("Input Submission Date: ");

		ModuleChoice = new ComboBox<Course>();
		ModuleChoice.setPrefSize(175,25);
		PNumberTxt = new TextField();
		FirstNameTxt = new TextField();
		LastNameTxt = new TextField();
		EmailTxt = new TextField();
		DateTxt = new DatePicker();

		final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {
			@Override
			public DateCell call(final DatePicker datePicker) {
				return new DateCell() {
					@Override
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);
						if (item.isBefore(DateTxt.getValue().now())) {
							setDisable(true);
							setStyle("-fx-background-color: #ffc0cb;");
						}
					}
				};
			}
		};
		DateTxt.setDayCellFactory(dayCellFactory);

		CreateProfileBtn = new Button("Create Profile");
		CreateProfileBtn.setPrefHeight(30);

		this.add(lblModuleChoice, 0, 0);
		this.add(ModuleChoice, 1, 0);
		this.add(lblPNumber, 0, 1);
		this.add(PNumberTxt, 1, 1);
		this.add(lblFirstName, 0, 2);
		this.add(FirstNameTxt, 1, 2);
		this.add(lblLastName, 0, 3);
		this.add(LastNameTxt, 1, 3);
		this.add(lblEmail, 0, 4);
		this.add(EmailTxt, 1, 4);
		this.add(lblDate, 0, 5);
		this.add(DateTxt, 1, 5);

		this.add(new HBox(), 0, 6);
		this.add(CreateProfileBtn, 1, 6);
	}

	public void populateComboBox(Course[] courses) {
		ModuleChoice.getItems().addAll(courses);
		ModuleChoice.getSelectionModel().select(0);
	}
	public void addModule(Module a) {
		listModel.getItems().add(a);
	}
	public Course getCourseChoice() {
		return (Course) ModuleChoice.getSelectionModel().getSelectedItem();
	}
	public String getPNumberInput() {
		return PNumberTxt.getText();
	}
	public String getFirstName() {
		return FirstNameTxt.getText();
	}
	public String getLastName() {
		return LastNameTxt.getText();
	}
	public Name getNameInput() {
		String FirstName =  FirstNameTxt.getText();
		String LastName = LastNameTxt.getText();
		return new Name(FirstName, LastName);
	}
	public String getEmailInput() {
		return EmailTxt.getText();
	}
	public LocalDate getDateTxt() {
		return DateTxt.getValue();
	}

	public void ResetFields() {
		FirstNameTxt.setText("");
		LastNameTxt.setText("");
		EmailTxt.setText("");
	}

	public void setStudentDetails(StudentProfile details) {
		ModuleChoice.setValue(details.getCourse());
		PNumberTxt.setText(details.getpNumber());
		FirstNameTxt.setText(details.getStudentName().getFirstName());
		LastNameTxt.setText(details.getStudentName().getFamilyName());
		EmailTxt.setText(details.getEmail());

		LocalDate date = details.getDate();
		DateTxt.setValue(date);
	}


	//method to attach the Profile handler
	public void addProfileListener(EventHandler<ActionEvent> handler) {
		CreateProfileBtn.setOnAction(handler);
	}
}