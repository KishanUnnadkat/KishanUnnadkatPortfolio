package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.input.KeyCombination;

public class StudentMenuBar extends MenuBar {

	private MenuItem loadItem, saveItem, exitItem, aboutItem;

	public StudentMenuBar() {
		Menu menu;

		menu = new Menu("File");
		loadItem = new MenuItem("Load Student Profile");
		loadItem.setAccelerator(KeyCombination.keyCombination("SHORTCUT+L"));
		menu.getItems().add(loadItem);
		saveItem = new MenuItem("Save Student Profile");
		saveItem.setAccelerator(KeyCombination.keyCombination("SHORTCUT+S"));
		menu.getItems().add(saveItem);
		menu.getItems().add(new SeparatorMenuItem());
		exitItem = new MenuItem("Exit");
		exitItem.setAccelerator(KeyCombination.keyCombination("SHORTCUT+X"));
		menu.getItems().add(exitItem);
		this.getMenus().add(menu); //add the menu to this menubar
		menu = new Menu("Help");
		aboutItem = new MenuItem("About");

		aboutItem.setAccelerator(KeyCombination.keyCombination("SHORTCUT+A"));
		menu.getItems().add(aboutItem);
		this.getMenus().add(menu);
	}


	//these methods allow handlers to be externally attached to this view by the controller
	public void addLoadHandler(EventHandler<ActionEvent> handler) {
		loadItem.setOnAction(handler);
	}
    public void addSaveHandler(EventHandler<ActionEvent> handler) {
  		saveItem.setOnAction(handler);
  	}
    public void addExitHandler(EventHandler<ActionEvent> handler) {
  		exitItem.setOnAction(handler);
  	}
    public void addAboutHandler(EventHandler<ActionEvent> handler) {
  		aboutItem.setOnAction(handler);
  	}
}