package view;

import javafx.animation.FadeTransition;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TabPane.TabClosingPolicy;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import view.CreateProfileTab.CreateProfileTab;
import view.ModulesTab.ModulesTab;
import view.OverviewSelectionTab.OverviewSelectionTab;

public class StudentRootPane extends VBox {

	private StudentMenuBar menuBar;
	private CreateProfileTab cpt;
	private ModulesTab mt;
	private OverviewSelectionTab op;
	private TabPane tp;
	private ProgressBar pb;
	private ProgressIndicator pi;

	public StudentRootPane() {
		this.setPrefSize(800, 500);

		menuBar = new StudentMenuBar();
		this.getChildren().addAll(menuBar);

		tp = new TabPane();
		cpt = new CreateProfileTab();
		Tab t1 = new Tab("Create Profile", cpt);
		tp.getTabs().add(t1);
		mt = new ModulesTab();
		Tab t2 = new Tab("Select Modules", mt);
		tp.getTabs().add(t2);
		op = new OverviewSelectionTab();
		Tab t3 = new Tab("Overview Selection", op);
		tp.getTabs().add(t3);
		tp.setTabClosingPolicy(TabClosingPolicy.UNAVAILABLE);

		HBox progressBox = new HBox();
		pb = new ProgressBar(0.33);
		pi = new ProgressIndicator(0.33);
		progressBox.getChildren().addAll(pb,pi);

		this.getChildren().addAll(tp, progressBox);
	}


	public StudentMenuBar getMenuBar() {
		return menuBar;
	}
	public CreateProfileTab getCreateProfileTab() {
		return cpt;
	}
	public ModulesTab getModulesTab() {
		return mt;
	}
	public OverviewSelectionTab getOverviewSelectionTab() {
		return op;
	}
	public void changeTab(int index) {
		tp.getSelectionModel().select(index);
	}
	public double getProgressBar() {
		return pb.getProgress();
	}
	public void setProgressBar(double x) {
		pb.setProgress(x);
	}
	public double getProgressIndicator() {
		return pi.getProgress();
	}
	public void setProgressIndicator(double x) {
		pi.setProgress(x);
	}
	public void fadeAnimation() {
		FadeTransition ft = new FadeTransition(Duration.millis(1000), this);
		ft.setFromValue(1.0);
		ft.setToValue(0.1);
		ft.setCycleCount(2);
		ft.setAutoReverse(true);
		ft.play();
	}
}