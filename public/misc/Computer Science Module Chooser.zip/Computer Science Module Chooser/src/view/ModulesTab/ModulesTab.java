package view.ModulesTab;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import model.Module;

public class ModulesTab extends BorderPane{

	private Button ResetBtn, RemoveBtn, AddBtn, SubmitBtn;
	private Label Creditlbl;
	private TextField CreditTxt;
	private ListView<Module> UnselectedList, SelectedList;

	public ModulesTab() {
		HBox hbox1 = new HBox();
		VBox UnselectedBox = new VBox();
		Label lblUnselectedModules = new Label("Unselected Modules");
		UnselectedList = new ListView<Module>();
		UnselectedList.setPrefSize(350, 300);
		UnselectedBox.setPadding(new Insets(20,0,0,30));
		UnselectedBox.getChildren().addAll(lblUnselectedModules, UnselectedList);

		VBox SelectedBox = new VBox();
		Label lblSelectedModules = new Label("Selected Modules");
		SelectedList = new ListView<Module>();
		SelectedList.setPrefSize(350, 300);
		SelectedBox.setPadding(new Insets(20,30,0,0));
		SelectedBox.getChildren().addAll(lblSelectedModules, SelectedList);
		hbox1.getChildren().addAll(UnselectedBox, SelectedBox);
		HBox.setHgrow(UnselectedBox, Priority.ALWAYS);
		HBox.setHgrow(SelectedBox, Priority.ALWAYS);
		this.setCenter(hbox1);

		HBox CreditsBox = new HBox();
		Creditlbl = new Label("Current credits: ");
		CreditTxt = new TextField("");
		CreditTxt.setEditable(false);
		CreditTxt.setPrefWidth(70);
		CreditsBox.setAlignment(Pos.CENTER);
		CreditsBox.getChildren().addAll(Creditlbl, CreditTxt);

		HBox ButtonsBox = new HBox();
		ResetBtn = new Button("Reset");
		ResetBtn.setPrefSize(70, 30);
		RemoveBtn = new Button("Remove");
		RemoveBtn.setPrefSize(70, 30);
		AddBtn = new Button("Add");
		AddBtn.setPrefSize(70, 30);
		SubmitBtn = new Button("Submit");
		SubmitBtn.setPrefSize(70, 30);
		ButtonsBox.setAlignment(Pos.CENTER);
		ButtonsBox.setPadding(new Insets(10,0,0,0));
		ButtonsBox.getChildren().addAll(ResetBtn, RemoveBtn, AddBtn, SubmitBtn);

		VBox joinBox = new VBox();
		joinBox.getChildren().addAll(CreditsBox, ButtonsBox);
		this.setBottom(joinBox);
	}


	//METHODS
	public ListView<Module> getSelectedList() {
		return SelectedList;
	}
	public void setSelectedList(ListView<Module> x) {
		SelectedList.getItems().clear();
		SelectedList.getItems().addAll(x.getItems());
		UnselectedList.getItems().removeAll(x.getItems());
		String credits = Integer.toString(getTotalCredit());
		setCredits(credits);
	}
	public int getUnselectedListSize() {
		return UnselectedList.getItems().size();
	}
	public void addUnselectedModule(Module m) {
		UnselectedList.getItems().add(m);
		SelectedList.getItems().remove(m);
	}
	public void addSelectedModule(Module m) {
		SelectedList.getItems().add(m);
		UnselectedList.getItems().remove(m);
	}
	public Module getSelectedItemInUnselectedList() {
		return UnselectedList.getSelectionModel().getSelectedItem();
	}
	public Module getSelectedItemInSelectedList() {
		return SelectedList.getSelectionModel().getSelectedItem();
	}
	public boolean IsSelectedListItemMandatory() {
		return SelectedList.getSelectionModel().getSelectedItem().isMandatory();
	}
	public int getTotalCredit() {
		int TotalCreds = 0;
		for(int i=0; i<SelectedList.getItems().size(); i++) {
			TotalCreds = TotalCreds + SelectedList.getItems().get(i).getCredits();
		}
		return TotalCreds;
	}
	public void setCredits(String x) {
		CreditTxt.setText(x);
	}
	public void ResetLists() {
		UnselectedList.getItems().clear();
		SelectedList.getItems().clear();
	}

	//EVENT HANDLERS
	public void addResetListener(EventHandler<ActionEvent> handler) {
		ResetBtn.setOnAction(handler);
	}
	public void addRemoveHandler(EventHandler<ActionEvent> handler) {
		RemoveBtn.setOnAction(handler);
	}
	public void addAddHandler(EventHandler<ActionEvent> handler) {
		AddBtn.setOnAction(handler);
	}
	public void addSubmitHandler(EventHandler<ActionEvent> handler) {
		SubmitBtn.setOnAction(handler);
	}
}