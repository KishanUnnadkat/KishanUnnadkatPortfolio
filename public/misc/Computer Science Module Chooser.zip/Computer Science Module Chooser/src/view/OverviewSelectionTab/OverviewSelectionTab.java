package view.OverviewSelectionTab;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class OverviewSelectionTab extends BorderPane {
	private TextArea StudentInfo;
	private Button SaveOverviewBtn;

	public OverviewSelectionTab() {
		StudentInfo = new TextArea("Overview will appear here");
		StudentInfo.setEditable(false);
		this.setCenter(StudentInfo);
		this.setPadding(new Insets(40, 40, 40, 40));

		HBox SaveOverview = new HBox();
		SaveOverviewBtn = new Button("Save Overview");
		SaveOverviewBtn.setPrefHeight(30);
		SaveOverview.setPadding(new Insets(15,0,0,0));
		SaveOverview.setAlignment(Pos.CENTER);
		SaveOverview.getChildren().addAll(SaveOverviewBtn);
		this.setBottom(SaveOverview);
	}

	//METHODS
	public void setStudentProfile(String overview) {
		StudentInfo.appendText(overview);
	}
	public void clearStudentProfile() {
		StudentInfo.clear();
	}
	public TextArea getStudentProfile() {
		return StudentInfo;
	}

	//EVENT HANDLER
	public void addOverviewHandler(EventHandler<ActionEvent> handler) {
		SaveOverviewBtn.setOnAction(handler);
	}

}