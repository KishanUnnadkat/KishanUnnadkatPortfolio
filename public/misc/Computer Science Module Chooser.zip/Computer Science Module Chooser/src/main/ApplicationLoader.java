package main;

import controller.StudentController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.StudentProfile;
import view.StudentRootPane;

public class ApplicationLoader extends Application {

	private StudentRootPane view;

	public void init() {
		view = new StudentRootPane();
		StudentProfile model = new StudentProfile();
		new StudentController(view, model);
	}

	@Override
	public void start(Stage stage) throws Exception {
		stage.setMinHeight(450);
		stage.setMinWidth(750);
		stage.setMaxHeight(550);
		stage.setMaxWidth(850);
		stage.setTitle("Final Year Module Chooser Tool");
		stage.setScene(new Scene(view));
		view.getStylesheets().add("stylesheet.css");
		stage.show();
	}

	public static void main(String[] args) {
		launch(args);
	}


}